.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
    :alt: License: AGPL-3

WEB RESPONSIVE
==============
This module adds responsiveness to web backend.

Configuration
=============
No additional configurations needed.

Company
-------
* `Baluba Developpement <https://baluba.ma/>`__

License
-------
General Public License, Version 3 (AGPL v3).
(https://www.gnu.org/licenses/agpl-3.0-standalone.html)

Credits
-------
Developer: (V17): Ali EL MALKI @Baluba-Developpement,Contact : a.elmalki@baluba.ma

Contacts
--------
* Mail Contact : a.elmalki@baluba.ma
* Website : https://baluba.ma

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://baluba.ma

This module is maintained by Baluba Developpement.
For support and more information, please visit `Our Website <https://baluba.ma/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__
