## Module <responsive_web>

#### 25.03.2024
#### Version 17.0.1.0.0
#### ADD

- Initial commit for Web Responsive